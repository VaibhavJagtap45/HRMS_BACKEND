const express = require("express");
const attendanceController = require("../controllers/attendanceController");
const { authorize, protect } = require("../middleware/authGuard");

const router = express.Router();

// All routes require a valid JWT
router.use(protect);

// ── HR: Manual & bulk operations ────────────────────────────────────────────
// POST /api/v1/attendance/manual  — Add a single punch entry (HR only)
router.post("/manual", authorize("hr"), attendanceController.createManualAttendance);

// POST /api/v1/attendance/bulk-upload  — Excel bulk import (HR only)
router.post(
  "/bulk-upload",
  authorize("hr"),
  attendanceController.attendanceUpload.single("file"),
  attendanceController.bulkUploadAttendance,
);

// POST /api/v1/attendance/import-csv  — Legacy CSV import alias (HR only)
router.post(
  "/import-csv",
  authorize("hr"),
  attendanceController.attendanceUpload.single("file"),
  attendanceController.legacyImportCsv,
);

// POST /api/v1/attendance/monthly-upload — Monthly pivot-table Excel import (HR only)
// Body: month, year (form-data fields alongside the file)
router.post(
  "/monthly-upload",
  authorize("hr"),
  attendanceController.attendanceUpload.single("file"),
  attendanceController.monthlyUploadAttendance,
);

// ── Read-only reporting ──────────────────────────────────────────────────────
// GET /api/v1/attendance/daily          — Daily punch log (HR: all; Employee: own)
router.get("/daily", attendanceController.legacyDailyReport);

// GET /api/v1/attendance/history/:employeeId — Per-employee punch history
router.get("/history/:employeeId", attendanceController.legacyHistory);

// GET /api/v1/attendance/import-logs   — Excel/CSV import audit trail (HR only)
router.get("/import-logs", authorize("hr"), attendanceController.getImportLogs);

// GET /api/v1/attendance/stats         — Attendance summary stats
router.get("/stats", attendanceController.getAttendanceStats);

// GET /api/v1/attendance/my/:month/:year — Employee's own monthly calendar data
router.get("/my/:month/:year", attendanceController.getMyMonthlyAttendance);

// ── CRUD on daily attendance records ────────────────────────────────────────
// GET /api/v1/attendance                — List records (HR: filterable; Employee: own)
router.get("/", attendanceController.listAttendance);

// POST /api/v1/attendance               — Create a daily attendance record (HR only)
router.post("/", authorize("hr"), attendanceController.createAttendanceRecord);

// PUT /api/v1/attendance/:id            — Update a record or event (HR only)
router.put("/:id", authorize("hr"), attendanceController.updateAttendanceRecord);

// DELETE /api/v1/attendance/:id         — Delete a record or event (HR only)
router.delete("/:id", authorize("hr"), attendanceController.deleteAttendanceRecord);

module.exports = router;
